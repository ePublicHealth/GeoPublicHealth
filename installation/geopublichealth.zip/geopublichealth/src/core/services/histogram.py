# -*- coding: utf-8 -*-
"""
/***************************************************************************

                                 GeoPublicHealth
                                 A QGIS plugin

                              -------------------
        begin                : 2026-01-26
        copyright            : (C) 2026 by GeoPublicHealth Team
        email                : info@geopublichealth.org
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from typing import List, Tuple


def renderer_ranges(renderer) -> List[Tuple[float, float, str, object]]:
    if renderer is None:
        return []

    ranges = []
    for ran in renderer.ranges():
        ranges.append((ran.lowerValue(), ran.upperValue(), ran.label(), ran.symbol()))
    return ranges
