# -*- coding: utf-8 -*-
"""
/***************************************************************************

                               GeoPublicHealth
                                 A QGIS plugin

                              -------------------
        begin                : 2016-02-17
        copyright            : (C) 2016 by ePublicHealth
        email                : manuel@epublichealth.co

        Based on the work of Geohealth
        begin                : 2014-08-20
        copyright            : (C) 2014 by Etienne Trimaille
        email                : etienne@trimaille.eu
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
import os.path
from tempfile import NamedTemporaryFile
from qgis.PyQt.QtWidgets import (
    QDialog, QDialogButtonBox, QApplication, QFileDialog
)
from qgis.PyQt.QtCore import QVariant, Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor

from qgis.utils import Qgis
from qgis.core import (
    QgsField, QgsRendererCategory, QgsCategorizedSymbolRenderer,
    QgsGradientColorRamp, QgsGraduatedSymbolRenderer, QgsSymbol,
    QgsVectorFileWriter, QgsFeature, QgsVectorLayer, QgsProject,
    QgsGeometry, QgsMapLayerProxyModel, QgsFieldProxyModel, QgsWkbTypes
)
from qgis.gui import QgsFieldComboBox, QgsMapLayerComboBox

import numpy as np
import libpysal
from libpysal.weights import Queen, Rook
from esda.moran import Moran_Local

from GeoPublicHealth.src.core.graph_toolbar import CustomNavigationToolbar
from GeoPublicHealth.src.core.tools import display_message_bar, tr
from GeoPublicHealth.src.core.exceptions import (
    GeoPublicHealthException, NoLayerProvidedException, FieldExistingException, NotANumberException
)
from GeoPublicHealth.src.core.stats import Stats
from GeoPublicHealth.src.utilities.resources import get_ui_class

FORM_CLASS = get_ui_class('analysis', 'autocorrelation.ui')

class CommonAutocorrelationDialog(QDialog):

    signalAskCloseWindow = pyqtSignal(int, name='signalAskCloseWindow')
    signalStatus = pyqtSignal(int, str, name='signalStatus')

    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.name_field = None
        self.admin_layer = None
        self.figure = None
        self.canvas = None
        self.toolbar = None
        self.output_file_path = None
        self.output_layer = None
        self.use_area = None

    def setup_ui(self):
        self.button_browse.clicked.connect(self.open_file_browser)
        self.button_box_ok.button(QDialogButtonBox.Ok).clicked.connect(self.run_stats)
        self.button_box_ok.button(QDialogButtonBox.Cancel).clicked.connect(self.hide)
        self.button_box_ok.button(QDialogButtonBox.Cancel).clicked.connect(self.signalAskCloseWindow.emit)
        self.cbx_aggregation_layer.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.cbx_indicator_field.setFilters(QgsFieldProxyModel.Numeric)
        self.cbx_indicator_field.setLayer(self.cbx_aggregation_layer.currentLayer())
        self.cbx_aggregation_layer.layerChanged.connect(self.cbx_indicator_field.setLayer)
        self.lisa = {
            1: ("#b92815", "High - High"),
            2: ("#3f70df", "Low - High"),
            3: ("#aecbdd", "Low - Low"),
            4: ("#e79e2c", "High - Low")
        }

    def open_file_browser(self):
        """Method to open file browser and get output file path."""
        output_file, __ = QFileDialog.getSaveFileName(
            self.parent, tr('Save shapefile'), filter='SHP (*.shp)')
        self.le_output_filepath.setText(output_file)

    def run_stats(self):
        try:
            self.prepare_run()
            self.admin_layer = self.cbx_aggregation_layer.currentLayer()
            input_name = self.admin_layer.name()
            field = self.cbx_indicator_field.currentField()
            self.layer = QgsProject.instance().mapLayersByName(input_name)[0]
            self.output_file_path = self.le_output_filepath.text()
            self.check_layer_and_file_path()
            crs_admin_layer = self.admin_layer.crs()
            admin_layer_provider = self.layer.dataProvider()
            fields = admin_layer_provider.fields()
            self.check_existing_field(fields)
            self.append_new_fields(fields)
            file_writer = self.prepare_file_writer(fields, crs_admin_layer)
            w = self.get_weights()
            y = self.get_indicator_values(field)
            lm = self.calculate_moran_local(y, w)
            sig_q = lm.q * (lm.p_sim <= 0.05)
            self.create_output_features(file_writer, lm, sig_q)
            del file_writer
            self.output_layer = self.create_output_layer(field)
            QgsProject.instance().addMapLayer(self.output_layer)
            self.add_symbology()
            self.signalStatus.emit(3, tr('Successful process'))
        except GeoPublicHealthException as e:
            display_message_bar(msg=e.msg, level=e.level, duration=e.duration)
        finally:
            self.end_run()

    def prepare_run(self):
        self.button_box_ok.setDisabled(True)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        QApplication.processEvents()

    def end_run(self):
        self.button_box_ok.setDisabled(False)
        QApplication.restoreOverrideCursor()
        QApplication.processEvents()

    def check_layer_and_file_path(self):
        if not self.admin_layer:
            raise NoLayerProvidedException

        if not self.output_file_path:
            with NamedTemporaryFile(delete=False, suffix='-geopublichealth.shp') as temp_file:
                self.output_file_path = temp_file.name
        else:
         if os.path.exists(self.output_file_path):
            base, extension = os.path.splitext(self.output_file_path)
            counter = 1
            while os.path.exists(self.output_file_path):
                self.output_file_path = f"{base}_{counter}{extension}"
                counter += 1

    def check_existing_field(self, fields):
        if fields.indexFromName(self.name_field) != -1:
            raise FieldExistingException(field=self.name_field)

    def append_new_fields(self, fields):
        fields.append(QgsField('LISA_P', QVariant.Double))
        fields.append(QgsField('LISA_Z', QVariant.Double))
        fields.append(QgsField('LISA_Q', QVariant.Int))
        fields.append(QgsField('LISA_I', QVariant.Double))
        fields.append(QgsField('LISA_C', QVariant.Double))

    def prepare_file_writer(self, fields, crs_admin_layer):
        return QgsVectorFileWriter(
            self.output_file_path,
            'utf-8',
            fields,
            QgsWkbTypes.Polygon,
            crs_admin_layer,
            'ESRI Shapefile')

    def get_weights(self):
        if self.cbx_contiguity.currentIndex() == 0:  # queen
            w = Queen.from_shapefile(self.admin_layer.source())
        else:  # 1 for rook
            w = Rook.from_shapefile(self.admin_layer.source())
        return w

    def get_indicator_values(self, field):
        f = libpysal.io.open(self.admin_layer.source().replace('.shp', '.dbf'))
        y = np.array(f.by_col[str(field)])
        return y

    def calculate_moran_local(self, y, w):
        return Moran_Local(y, w, transformation="r", permutations=999)

    def create_output_features(self, file_writer, lm, sig_q):
        for i, feature in enumerate(self.admin_layer.getFeatures()):
            attributes = feature.attributes()
            attributes.append(float(lm.p_sim[i]))
            attributes.append(float(lm.z_sim[i]))
            attributes.append(int(lm.q[i]))
            attributes.append(float(lm.Is[i]))
            attributes.append(int(sig_q[i]))

            new_feature = QgsFeature()
            new_geom = QgsGeometry(feature.geometry())
            new_feature.setAttributes(attributes)
            new_feature.setGeometry(new_geom)
            file_writer.addFeature(new_feature)

    def create_output_layer(self, field):
        output_layer = QgsVectorLayer(
            self.output_file_path,
            "LISA Moran's I - " + field,
            'ogr')
        return output_layer

    def add_symbology(self):
        categories = []
        for lisaCategory, (color, label) in list(self.lisa.items()):
            sym = QgsSymbol.defaultSymbol(self.output_layer.geometryType())
            sym.setColor(QColor(color))
            category = QgsRendererCategory(lisaCategory, sym, label)
            categories.append(category)

        new_layer = QgsVectorLayer(
            self.output_layer.source(),
            self.output_layer.name() + " significance test",
            self.output_layer.providerType())
        self.output_layer.setOpacity(0.4)
        QgsProject.instance().addMapLayer(new_layer)

        renderer = QgsCategorizedSymbolRenderer(
            'LISA_Q',
            categories)

        self.output_layer.setRenderer(renderer)

        symbol = QgsSymbol.defaultSymbol(QgsWkbTypes.geometryType(QgsWkbTypes.Polygon))

        color_ramp = QgsGradientColorRamp(QColor(0, 0, 0), QColor(255, 0, 0))

        renderer = QgsGraduatedSymbolRenderer.createRenderer(
            new_layer,
            'LISA_C',
            4,
            QgsGraduatedSymbolRenderer.Jenks,
            symbol,
            color_ramp)

        new_layer.setRenderer(renderer)
        new_layer.setOpacity(0.4)

class AutocorrelationDialog(CommonAutocorrelationDialog, FORM_CLASS):
    def __init__(self, parent=None):
        super().__init__(parent)
        FORM_CLASS.setupUi(self, self)

        self.use_area = False

        self.setup_ui()

    def run_stats(self):
        CommonAutocorrelationDialog.run_stats(self)
